﻿using cubemesweb.dair_mobile;
using dair.cube;
using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics.Contracts;
using Wisej.Web;


namespace cubemesweb.dair_msl
{
    public partial class FormEmpList : Page
    {
        DataTable dtEmpList = null;
        DataRow drEmpDataLast = null;

        public Boolean isReady = false;

        public FormEmpList()
        {
            InitializeComponent();
        }

        public void doEqToEmpSync()
        {
            try
            {
                string sql = "insert into 인원_목록 (아이디) select 설비명 FROM eq_list WHERE 설비명 NOT IN (SELECT 아이디 FROM 인원_목록)";
                DMDB db = new DMDB();
                db.sqlExec(sql);
            }
            catch (Exception E)
            {
                cs.logError(E);
            }
        }

        public void reload()
        {
            try
            {
                DMDB db = new DMDB();

                string sql = "select * from ecg_raw_history_last  ";
                if(chkOrderID.Checked) { sql += " order by eq asc "; }
                else if (chkOrderTime.Checked) { sql += " order by writetime desc "; }
                dtEmpList = db.sqlToDT(sql);

                gvEmpList.RowCount = 0;
                gvEmpList.Invalidate();
                gvEmpList.RowCount = dtEmpList.Rows.Count;
                gvEmpList.Invalidate();
            }
            catch (Exception E)
            {
                cs.logError(E);
            }
        }

        private void gvEmpList_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {
            try
            {
                int r = e.RowIndex;
                int c = e.ColumnIndex;

                if (r < 0) return;
                if (c < 0) return;

                if(dtEmpList!=null)
                {
                    string col = gvEmpList.Columns[c].HeaderText;
                    if (gvEmpList.Columns[c].ToolTipText != "")
                        col = gvEmpList.Columns[c].ToolTipText;
                    string sv = "";

                    DataRow dr = dtEmpList.Rows[r];

                    //if (col == "아이디")
                    //{
                    //    sv = dr["설비명"].ToString();
                    //}
                    //else if (col == "성명")
                    //{
                    //    sv = dr["설비명"].ToString();
                    //}
                    //else if (col == "마지막 맥박")
                    //{
                    //    sv = "-";
                    //}
                    //else if (col == "마지막 측정시각")
                    //{
                    //    sv = "-";
                    //}

                    if (col.ToLower() == "distanceKM".ToLower())
                    {
                        double dM = cs.strToDouble(dr["distanceKM"].ToString()) / 1000.0;
                        sv = dM.ToString("0.0##");
                    }
                    else
                    {
                        sv = dr[col].ToString();
                    }

                    e.Value = sv;
                }
            }
            catch (Exception E)
            {
                cs.logError(E);
            }
        }

        private void FormEmpList_Load(object sender, EventArgs e)
        {

            timerTick.Enabled = true;
            doGridInit();

            reload();
        }

        public void doGridInit()
        {
            string key = "gvEmpList";

            DMDB db = new DMDB();

            for (int c = 0; c < gvEmpList.ColumnCount; c++)
            {
                gvEmpList.Columns[c].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                string col = gvEmpList.Columns[c].HeaderText;
                if (gvEmpList.Columns[c].ToolTipText != "")
                    col = gvEmpList.Columns[c].ToolTipText;
                double dw = cs.strToDouble(db.getConfig(key + "." + col + ".width", "100"));
                if(dw > 0)
                    gvEmpList.Columns[c].Width = (int)dw;
            }
            isReady = true;
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            doEqToEmpSync();
            doGridInit();
            reload();
        }

        private void gvEmpList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int r = e.RowIndex;
                int c = e.ColumnIndex;

                if (r < 0) return;
                if (c < 0) return;

                if (dtEmpList != null)
                {
                    string col = gvEmpList.Columns[c].HeaderText;
                    DataRow dr = dtEmpList.Rows[r];

                    string id = dr["eq"].ToString();

                    //Application.MainPage = new FormEmpDataViewer(id);

                    Application.Session["empid"] = id;

                    FormEmpOverview ff = new FormEmpOverview() { Name = Application.SessionId + ".FormEmpOverview" };
                    ff.Show();
                    ff.doEmpLoad();
                    ff.reload(id);
                }
            }
            catch (Exception E)
            {
                cs.logError(E);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Application.OpenPages[Application.SessionId + ".FormLoginMobile"].Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnNotice_Click(object sender, EventArgs e)
        {
            FormTableViewer ff = new FormTableViewer();
            ff.table = "board_notice";
            ff.Show();
        }

        private void gvEmpList_ColumnWidthChanged(object sender, DataGridViewColumnEventArgs e)
        {
            if (isReady == false)
                return;
            try
            {
                string key = "gvEmpList";

                //for(int c = 0;c<gvEmpList.Columns.Count;c++)
                
                {
                    string col = e.Column.HeaderText;
                    if (e.Column.ToolTipText != "")
                        col = e.Column.ToolTipText;

                    DMDB db = new DMDB();
                    db.setConfig(key + "." + col + ".width", e.Column.Width.ToString());   
                }
            }
            catch
            {

            }
        }

        private void timerTick_Tick(object sender, EventArgs e)
        {
            if(Visible)
            {
                if (chkAutoReload.Checked)
                {
                    reload();
                }
            }
        }
    }
}
