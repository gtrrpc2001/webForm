﻿
namespace cubemesweb.dair_msl
{
    partial class FormEmpList
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEmpList));
            this.panel1 = new Wisej.Web.Panel();
            this.panel18 = new Wisej.Web.Panel();
            this.button1 = new Wisej.Web.Button();
            this.panel5 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.styleSheetDAIR = new Wisej.Web.StyleSheet(this.components);
            this.pBack1 = new Wisej.Web.Panel();
            this.gvEmpList = new Wisej.Web.DataGridView();
            this.Column1 = new Wisej.Web.DataGridViewTextBoxColumn();
            this.Column2 = new Wisej.Web.DataGridViewTextBoxColumn();
            this.Column3 = new Wisej.Web.DataGridViewTextBoxColumn();
            this.Column4 = new Wisej.Web.DataGridViewTextBoxColumn();
            this.Column0 = new Wisej.Web.DataGridViewColumn();
            this.Column5 = new Wisej.Web.DataGridViewColumn();
            this.Column6 = new Wisej.Web.DataGridViewColumn();
            this.Column7 = new Wisej.Web.DataGridViewColumn();
            this.Column8 = new Wisej.Web.DataGridViewColumn();
            this.Column9 = new Wisej.Web.DataGridViewColumn();
            this.Column10 = new Wisej.Web.DataGridViewColumn();
            this.panel4 = new Wisej.Web.Panel();
            this.groupBox1 = new Wisej.Web.GroupBox();
            this.chkOrderID = new Wisej.Web.RadioButton();
            this.chkOrderTime = new Wisej.Web.RadioButton();
            this.chkAutoReload = new Wisej.Web.CheckBox();
            this.btnNotice = new Wisej.Web.Button();
            this.btnBack = new Wisej.Web.Button();
            this.btnReload = new Wisej.Web.Button();
            this.line1 = new Wisej.Web.Line();
            this.label1 = new Wisej.Web.Label();
            this.timerTick = new Wisej.Web.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pBack1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvEmpList)).BeginInit();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(32, 35, 49);
            this.panel1.Controls.Add(this.panel18);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = Wisej.Web.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1477, 48);
            this.panel1.TabIndex = 12;
            this.panel1.TabStop = true;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Transparent;
            this.panel18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel18.BackgroundImage")));
            this.panel18.BackgroundImageLayout = Wisej.Web.ImageLayout.Center;
            this.panel18.Dock = Wisej.Web.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(172, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1183, 48);
            this.panel18.TabIndex = 5;
            this.panel18.TabStop = true;
            this.panel18.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(32, 35, 49);
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = Wisej.Web.ImageLayout.Center;
            this.button1.BorderStyle = Wisej.Web.BorderStyle.None;
            this.button1.Dock = Wisej.Web.DockStyle.Right;
            this.button1.Location = new System.Drawing.Point(1355, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 48);
            this.button1.TabIndex = 4;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = Wisej.Web.ImageLayout.Center;
            this.panel5.Dock = Wisej.Web.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(172, 48);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(32, 35, 49);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = Wisej.Web.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 518);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1477, 48);
            this.panel2.TabIndex = 13;
            this.panel2.TabStop = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = Wisej.Web.ImageLayout.Center;
            this.panel3.Dock = Wisej.Web.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(959, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(518, 48);
            this.panel3.TabIndex = 4;
            this.panel3.TabStop = true;
            // 
            // styleSheetDAIR
            // 
            this.styleSheetDAIR.Styles = ".rounded-groupbox .qx-groupbox-frame\r\n{\r\n    border-radius: 10px\r\n}\r\n\r\n.rounded-p" +
    "anel\r\n{\r\n    border-radius: 10px\r\n}\r\n\r\n.rounded-button\r\n{\r\n    border-radius: 10" +
    "px\r\n}";
            // 
            // pBack1
            // 
            this.pBack1.Controls.Add(this.gvEmpList);
            this.pBack1.Controls.Add(this.panel4);
            this.pBack1.Dock = Wisej.Web.DockStyle.Fill;
            this.pBack1.Location = new System.Drawing.Point(0, 48);
            this.pBack1.Name = "pBack1";
            this.pBack1.Padding = new Wisej.Web.Padding(20);
            this.pBack1.Size = new System.Drawing.Size(1477, 470);
            this.pBack1.TabIndex = 14;
            this.pBack1.TabStop = true;
            // 
            // gvEmpList
            // 
            this.gvEmpList.AllowUserToResizeRows = false;
            this.gvEmpList.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column0,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10});
            this.gvEmpList.Dock = Wisej.Web.DockStyle.Fill;
            this.gvEmpList.Location = new System.Drawing.Point(20, 72);
            this.gvEmpList.MultiSelect = false;
            this.gvEmpList.Name = "gvEmpList";
            this.gvEmpList.RowHeadersVisible = false;
            this.gvEmpList.Size = new System.Drawing.Size(1437, 378);
            this.gvEmpList.TabIndex = 0;
            this.gvEmpList.VirtualMode = true;
            this.gvEmpList.CellValueNeeded += new Wisej.Web.DataGridViewCellValueEventHandler(this.gvEmpList_CellValueNeeded);
            this.gvEmpList.ColumnWidthChanged += new Wisej.Web.DataGridViewColumnEventHandler(this.gvEmpList_ColumnWidthChanged);
            this.gvEmpList.CellClick += new Wisej.Web.DataGridViewCellEventHandler(this.gvEmpList_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "아이디";
            this.Column1.Name = "Column1";
            this.Column1.ToolTipText = "eq";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "성명";
            this.Column2.Name = "Column2";
            this.Column2.ToolTipText = "eqname";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "측정시각";
            this.Column3.Name = "Column3";
            this.Column3.ToolTipText = "writetime";
            this.Column3.Width = 120;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "맥박";
            this.Column4.Name = "Column4";
            this.Column4.ToolTipText = "bpm";
            this.Column4.Width = 80;
            // 
            // Column0
            // 
            this.Column0.HeaderText = "HRV";
            this.Column0.Name = "Column0";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "칼로리";
            this.Column5.Name = "Column5";
            this.Column5.ToolTipText = "cal";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "활동칼로리";
            this.Column6.Name = "Column6";
            this.Column6.ToolTipText = "calexe";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "걸음";
            this.Column7.Name = "Column7";
            this.Column7.ToolTipText = "step";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "이동거리(km)";
            this.Column8.Name = "Column8";
            this.Column8.ToolTipText = "distanceKM";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "비정상맥박";
            this.Column9.Name = "Column9";
            this.Column9.ToolTipText = "arrcnt";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "체온(℃)";
            this.Column10.Name = "Column10";
            this.Column10.ToolTipText = "temp";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Controls.Add(this.chkAutoReload);
            this.panel4.Controls.Add(this.btnNotice);
            this.panel4.Controls.Add(this.btnBack);
            this.panel4.Controls.Add(this.btnReload);
            this.panel4.Controls.Add(this.line1);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = Wisej.Web.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(20, 20);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1437, 52);
            this.panel4.TabIndex = 1;
            this.panel4.TabStop = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkOrderID);
            this.groupBox1.Controls.Add(this.chkOrderTime);
            this.groupBox1.Location = new System.Drawing.Point(334, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(190, 43);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.Text = "정렬";
            // 
            // chkOrderID
            // 
            this.chkOrderID.Location = new System.Drawing.Point(93, 18);
            this.chkOrderID.Name = "chkOrderID";
            this.chkOrderID.Size = new System.Drawing.Size(90, 22);
            this.chkOrderID.TabIndex = 1;
            this.chkOrderID.TabStop = true;
            this.chkOrderID.Text = "아이디순";
            // 
            // chkOrderTime
            // 
            this.chkOrderTime.Checked = true;
            this.chkOrderTime.Location = new System.Drawing.Point(12, 18);
            this.chkOrderTime.Name = "chkOrderTime";
            this.chkOrderTime.Size = new System.Drawing.Size(75, 22);
            this.chkOrderTime.TabIndex = 0;
            this.chkOrderTime.TabStop = true;
            this.chkOrderTime.Text = "최신순";
            // 
            // chkAutoReload
            // 
            this.chkAutoReload.Checked = true;
            this.chkAutoReload.Location = new System.Drawing.Point(215, 14);
            this.chkAutoReload.Name = "chkAutoReload";
            this.chkAutoReload.Size = new System.Drawing.Size(122, 22);
            this.chkAutoReload.TabIndex = 8;
            this.chkAutoReload.Text = "자동 업데이트";
            // 
            // btnNotice
            // 
            this.btnNotice.Dock = Wisej.Web.DockStyle.Right;
            this.btnNotice.Location = new System.Drawing.Point(1281, 0);
            this.btnNotice.Name = "btnNotice";
            this.btnNotice.Size = new System.Drawing.Size(89, 44);
            this.btnNotice.TabIndex = 6;
            this.btnNotice.Text = " 공지사항";
            this.btnNotice.Click += new System.EventHandler(this.btnNotice_Click);
            // 
            // btnBack
            // 
            this.btnBack.Dock = Wisej.Web.DockStyle.Left;
            this.btnBack.Image = ((System.Drawing.Image)(resources.GetObject("btnBack.Image")));
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(67, 44);
            this.btnBack.TabIndex = 4;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnReload
            // 
            this.btnReload.Dock = Wisej.Web.DockStyle.Right;
            this.btnReload.Image = ((System.Drawing.Image)(resources.GetObject("btnReload.Image")));
            this.btnReload.Location = new System.Drawing.Point(1370, 0);
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(67, 44);
            this.btnReload.TabIndex = 2;
            this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
            // 
            // line1
            // 
            this.line1.Dock = Wisej.Web.DockStyle.Bottom;
            this.line1.Location = new System.Drawing.Point(0, 44);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1437, 8);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("default", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label1.Location = new System.Drawing.Point(73, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "실시간 사용자 현황";
            // 
            // timerTick
            // 
            this.timerTick.Tick += new System.EventHandler(this.timerTick_Tick);
            // 
            // FormEmpList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.Controls.Add(this.pBack1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "FormEmpList";
            this.Size = new System.Drawing.Size(1477, 566);
            this.Load += new System.EventHandler(this.FormEmpList_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.pBack1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvEmpList)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Wisej.Web.StyleSheet styleSheetDAIR;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel18;
        private Wisej.Web.Button button1;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel pBack1;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.DataGridView gvEmpList;
        private Wisej.Web.DataGridViewTextBoxColumn Column1;
        private Wisej.Web.DataGridViewTextBoxColumn Column2;
        private Wisej.Web.DataGridViewTextBoxColumn Column4;
        private Wisej.Web.DataGridViewTextBoxColumn Column3;
        private Wisej.Web.Line line1;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnReload;
        private Wisej.Web.Button btnBack;
        private Wisej.Web.Button btnNotice;
        private Wisej.Web.DataGridViewColumn Column0;
        private Wisej.Web.DataGridViewColumn Column5;
        private Wisej.Web.DataGridViewColumn Column6;
        private Wisej.Web.DataGridViewColumn Column7;
        private Wisej.Web.DataGridViewColumn Column8;
        private Wisej.Web.DataGridViewColumn Column9;
        private Wisej.Web.DataGridViewColumn Column10;
        private Wisej.Web.CheckBox chkAutoReload;
        private Wisej.Web.Timer timerTick;
        private Wisej.Web.GroupBox groupBox1;
        private Wisej.Web.RadioButton chkOrderID;
        private Wisej.Web.RadioButton chkOrderTime;
    }
}
